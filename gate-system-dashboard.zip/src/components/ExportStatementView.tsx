/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { RefreshCw, CheckSquare, Square, Search, Printer, File, ArrowLeftRight, HelpCircle } from 'lucide-react';
import { Container, Certificate, CertificateContainer } from '../types';
import { VESSELS, SHIPPING_AGENCIES, DESTINATIONS, CUSTOMS_OFFICES, CARGO_TYPES } from '../mockData';

interface ExportStatementViewProps {
  lang: 'ar' | 'en';
  permissions: {
    edit: boolean;
    approve: boolean;
  };
  containersList: Container[];
  setContainersList: React.Dispatch<React.SetStateAction<Container[]>>;
  certificatesList: Certificate[];
  setCertificatesList: React.Dispatch<React.SetStateAction<Certificate[]>>;
}

export const ExportStatementView: React.FC<ExportStatementViewProps> = ({
  lang,
  permissions,
  containersList,
  setContainersList,
  certificatesList,
  setCertificatesList,
}) => {
  const isRTL = lang === 'ar';

  const EMPTY_CERT: Certificate = {
    id: '',
    year: '',
    type: '',
    customsOffice: '',
    isCircular26: false,
    isTemporary: false,
    date: '',
    vesselName: '',
    shippingAgency: '',
    finalDestination: '',
    cargoType: '',
    clientName: '',
    remarks: '',
    hasWeightCheck: false,
    hasXRayCheck: false,
    caliberStandard: 'مستوفي العيار',
    totalQuantity: 0,
    grossWeight: 0,
    containers: [],
    cargoSubtype: '',
    maeCode: '',
    agencyText: '',
  };

  // Active form states (starts completely blank)
  const [activeCert, setActiveCert] = useState<Certificate>(EMPTY_CERT);

  // UI Selection states
  const [selectedLeftId, setSelectedLeftId] = useState<string | null>(null);
  const [selectedBottomId, setSelectedBottomId] = useState<string | null>(null);
  const [leftSearch, setLeftSearch] = useState('');
  const [lastModified, setLastModified] = useState('لا يوجد تعديل');

  // Notifications
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  // Retrieve handler
  const handleRetrieve = () => {
    if (certificatesList.length > 0) {
      const randomCert = certificatesList[Math.floor(Math.random() * certificatesList.length)];
      setActiveCert({ ...randomCert });
      showToast('تم استرجاع بيانات الشهادة بنجاح', 'info');
    } else {
      showToast('لا توجد شهادات محفوظة للاسترجاع', 'error');
    }
  };

  // Reset Form
  const handleNewFile = () => {
    setActiveCert(EMPTY_CERT);
    setSelectedBottomId(null);
    showToast('تم إنشاء نموذج شهادة جديد فارغ', 'success');
  };

  // Save active certificate
  const handleSaveCertificate = () => {
    if (!permissions.edit) {
      showToast('عفواً، لا تملك صلاحية التعديل', 'error');
      return;
    }
    
    let certToSave = { ...activeCert };
    if (!certToSave.id.trim()) {
      const currentContainerId = selectedLeftId || activeCert.containers[0]?.containerId || '';
      if (currentContainerId) {
        certToSave.id = `CERT-${currentContainerId.slice(-6)}`;
      } else {
        certToSave.id = `CERT-NEW-${Math.floor(Math.random() * 10000)}`;
      }
    }

    const exists = certificatesList.some((c) => c.id === certToSave.id);
    if (exists) {
      setCertificatesList(certificatesList.map((c) => (c.id === certToSave.id ? certToSave : c)));
      showToast('تم تحديث الشهادة بنجاح');
    } else {
      setCertificatesList([...certificatesList, certToSave]);
      showToast('تم حفظ الشهادة الجديدة بنجاح');
    }

    // Remove the saved container(s) from the left sidebar containers list
    const containerIdsToRemove = [
      ...(selectedLeftId ? [selectedLeftId] : []),
      ...activeCert.containers.map((c) => c.containerId),
    ];
    if (containerIdsToRemove.length > 0) {
      setContainersList((prev) => prev.filter((c) => !containerIdsToRemove.includes(c.id)));
    }

    // Reset active form so it becomes completely blank/empty
    setActiveCert(EMPTY_CERT);
    setSelectedLeftId(null);
    setLastModified(new Date().toLocaleTimeString('ar-EG'));
  };

  // Approve active certificate
  const handleApproveCertificate = () => {
    if (!permissions.approve) {
      showToast('عفواً، لا تملك صلاحية الاعتماد', 'error');
      return;
    }
    showToast(`تم اعتماد الشهادة الجمركية ${activeCert.id} نهائياً`, 'success');
  };

  // Select a container from left list -> automatically populates center form
  const handleSelectLeftContainer = (containerId: string) => {
    setSelectedLeftId(containerId);

    // Look for a saved certificate containing this container
    const matchingCert = certificatesList.find((c) =>
      c.containers.some((item) => item.containerId === containerId)
    );

    if (matchingCert) {
      setActiveCert({ ...matchingCert });
      showToast(`تم تحميل الشهادة رقم ${matchingCert.id} للحاوية المختارة`, 'info');
    } else {
      const container = containersList.find((c) => c.id === containerId);
      if (container) {
        // Pre-fill a new certificate for this container
        setActiveCert({
          id: `CERT-${container.id.slice(-4)}`,
          year: '2026',
          type: 'صادر نهائي (Final Export)',
          customsOffice: CUSTOMS_OFFICES[0],
          isCircular26: true,
          isTemporary: false,
          date: '06-07-2026',
          vesselName: container.vesselName || VESSELS[0],
          shippingAgency: SHIPPING_AGENCIES[0],
          finalDestination: DESTINATIONS[0],
          cargoType: CARGO_TYPES[0],
          clientName: container.consignee || '',
          remarks: '',
          hasWeightCheck: true,
          hasXRayCheck: false,
          caliberStandard: 'مستوفي العيار',
          totalQuantity: 1,
          grossWeight: container.weight,
          cargoSubtype: container.type || 'GP',
          maeCode: container.line || 'MAE',
          agencyText: 'التابعه لتوكيل',
          containers: [
            {
              containerId: container.id,
              isStopped: false,
              isApproved: false,
              isSaved: true,
              caliber: container.caliber || 'Standard',
              size: container.size,
              releaseRoute: 'قيد التدقيق',
              customsRoute: container.customsRoute === 'Green Channel' ? 'المسار الأخضر' : container.customsRoute === 'Yellow Channel' ? 'المسار الأصفر' : 'المسار الأحمر',
              weight: container.weight,
            }
          ]
        });
        showToast(`تم تحميل بيانات الحاوية ${containerId} في النموذج`, 'success');
      }
    }
  };

  // Add container from left list to right table
  const handleAddContainerToCertificate = () => {
    if (!selectedLeftId) {
      showToast('يرجى اختيار حاوية من القائمة اليسرى أولاً', 'error');
      return;
    }

    const containerData = containersList.find((c) => c.id === selectedLeftId);
    if (!containerData) return;

    const currentCertId = activeCert.id.trim() ? activeCert.id : `CERT-${containerData.id.slice(-4)}`;

    if (activeCert.containers.some((item) => item.containerId === selectedLeftId)) {
      showToast('الحاوية مضافة بالفعل لهذه الشهادة', 'error');
      return;
    }

    const newCertContainer: CertificateContainer = {
      containerId: containerData.id,
      isStopped: false,
      isApproved: false,
      isSaved: true,
      caliber: containerData.caliber || 'Standard',
      size: containerData.size,
      releaseRoute: 'قيد التدقيق',
      customsRoute: containerData.customsRoute === 'Green Channel' ? 'المسار الأخضر' : containerData.customsRoute === 'Yellow Channel' ? 'المسار الأصفر' : 'المسار الأحمر',
      weight: containerData.weight,
    };

    const updatedContainers = [...activeCert.containers, newCertContainer];
    
    // Recalculate weights & quantity
    const totalQty = updatedContainers.length;
    const grossWt = updatedContainers.reduce((sum, item) => sum + item.weight, 0);

    const updatedCert = {
      ...activeCert,
      id: currentCertId,
      year: activeCert.year || '2026',
      type: activeCert.type || 'صادر نهائي (Final Export)',
      customsOffice: activeCert.customsOffice || CUSTOMS_OFFICES[0],
      vesselName: activeCert.vesselName || containerData.vesselName || VESSELS[0],
      shippingAgency: activeCert.shippingAgency || SHIPPING_AGENCIES[0],
      finalDestination: activeCert.finalDestination || DESTINATIONS[0],
      cargoType: activeCert.cargoType || CARGO_TYPES[0],
      clientName: activeCert.clientName || containerData.consignee || '',
      cargoSubtype: activeCert.cargoSubtype || containerData.type || 'GP',
      containers: updatedContainers,
      totalQuantity: totalQty,
      grossWeight: grossWt,
    };

    setActiveCert(updatedCert);

    // Sync with certificatesList
    const exists = certificatesList.some((c) => c.id === currentCertId);
    if (exists) {
      setCertificatesList(certificatesList.map((c) => (c.id === currentCertId ? updatedCert : c)));
    } else {
      setCertificatesList([...certificatesList, updatedCert]);
    }

    showToast(`تم إضافة الحاوية ${selectedLeftId} للشهادة`);
    setSelectedLeftId(null);
  };

  // Editable bottom list state handlers
  const handleUpdateRowValue = (key: string, field: keyof Certificate, value: any) => {
    const updated = certificatesList.map((c) => {
      const matchKey = c.localId || c.id;
      if (matchKey === key) {
        return { ...c, [field]: value };
      }
      return c;
    });
    setCertificatesList(updated);
    const activeKey = activeCert.localId || activeCert.id;
    if (activeKey === key) {
      setActiveCert((prev) => ({ ...prev, [field]: value }));
    }
  };

  const handleUpdateRowID = (key: string, newId: string) => {
    const updated = certificatesList.map((c) => {
      const matchKey = c.localId || c.id;
      if (matchKey === key) {
        return { ...c, id: newId };
      }
      return c;
    });
    setCertificatesList(updated);
    const activeKey = activeCert.localId || activeCert.id;
    if (activeKey === key) {
      setActiveCert((prev) => ({ ...prev, id: newId }));
    }
  };

  const handleAddNewRow = () => {
    const tempId = ''; // Start empty
    const uniqueLocalId = `local-${Date.now() % 100000}-${Math.floor(Math.random() * 1000)}`;
    const newCert: Certificate = {
      localId: uniqueLocalId,
      id: tempId,
      year: '2026',
      type: 'صادر نهائي (Final Export)',
      customsOffice: CUSTOMS_OFFICES[0],
      isCircular26: false,
      isTemporary: false,
      date: '06-07-2026',
      vesselName: VESSELS[0],
      shippingAgency: SHIPPING_AGENCIES[0],
      finalDestination: '', // Start empty
      cargoType: CARGO_TYPES[0],
      clientName: '',
      remarks: '',
      hasWeightCheck: false,
      hasXRayCheck: false,
      caliberStandard: 'مستوفي العيار',
      totalQuantity: 1,
      grossWeight: 0,
      cargoSubtype: 'GP',
      containers: [],
    };
    setCertificatesList([...certificatesList, newCert]);
    setActiveCert(newCert);
    showToast('تم إضافة سطر جديد فارغ يدوي', 'info');
  };

  const handleDeleteRow = (key: string) => {
    const updated = certificatesList.filter((c) => (c.localId || c.id) !== key);
    setCertificatesList(updated);
    const activeKey = activeCert.localId || activeCert.id;
    if (activeKey === key) {
      setActiveCert(EMPTY_CERT);
    }
    showToast('تم حذف السطر بنجاح', 'info');
  };

  const handleSaveRow = (key: string) => {
    const cert = certificatesList.find((c) => (c.localId || c.id) === key);
    if (cert) {
      showToast(`تم حفظ السطر ${cert.id || 'الفارغ'} بنجاح`, 'success');
    }
  };

  // Toggle checklist inside bottom table row
  const toggleContainerRowProp = (containerId: string, property: 'isStopped' | 'isApproved' | 'isSaved') => {
    const updated = activeCert.containers.map((item) => {
      if (item.containerId === containerId) {
        return { ...item, [property]: !item[property] };
      }
      return item;
    });
    setActiveCert({ ...activeCert, containers: updated });
  };

  // Delete container from bottom table
  const handleDeleteContainerFromCert = (containerId: string) => {
    const updated = activeCert.containers.filter((item) => item.containerId !== containerId);
    const totalQty = updated.length;
    const grossWt = updated.reduce((sum, item) => sum + item.weight, 0);

    setActiveCert({
      ...activeCert,
      containers: updated,
      totalQuantity: totalQty,
      grossWeight: grossWt,
    });
    if (selectedBottomId === containerId) {
      setSelectedBottomId(null);
    }
    showToast('تم إزالة الحاوية من الشهادة');
  };

  // Apply batch release status to bottom containers
  const applyReleaseStatusToSelected = (statusType: 'Ready' | 'HoldDocs' | 'HoldInspect') => {
    if (!selectedBottomId) {
      showToast('يرجى تحديد حاوية من الجدول السفلي أولاً', 'error');
      return;
    }

    const updated = activeCert.containers.map((item) => {
      if (item.containerId === selectedBottomId) {
        let routeText = 'قيد التدقيق';
        let isStoppedValue = item.isStopped;
        let isApprovedValue = item.isApproved;

        if (statusType === 'Ready') {
          routeText = 'مفرج (جاهز)';
          isStoppedValue = false;
          isApprovedValue = true;
        } else if (statusType === 'HoldDocs') {
          routeText = 'موقوف مستندات';
          isStoppedValue = true;
          isApprovedValue = false;
        } else if (statusType === 'HoldInspect') {
          routeText = 'موقوف للكشف';
          isStoppedValue = true;
          isApprovedValue = false;
        }

        return {
          ...item,
          releaseRoute: routeText,
          isStopped: isStoppedValue,
          isApproved: isApprovedValue,
        };
      }
      return item;
    });

    setActiveCert({ ...activeCert, containers: updated });
    showToast(`تم تحديث حالة الحاوية ${selectedBottomId} بنجاح`, 'success');
  };

  // Left panel filtered containers
  const filteredLeftContainers = containersList.filter((c) => {
    const matchesSearch = c.id.toLowerCase().includes(leftSearch.toLowerCase()) || c.line.toLowerCase().includes(leftSearch.toLowerCase());
    const alreadyAdded = activeCert.containers.some((item) => item.containerId === c.id);
    return matchesSearch && !alreadyAdded;
  });

  return (
    <div className="flex h-full bg-[#9c9c9c] p-1 overflow-hidden font-sans select-none" dir="ltr">
      
      {/* Toast Notification block */}
      {toast && (
        <div className={`fixed top-4 left-4 z-50 flex items-center gap-3 px-4 py-3 rounded shadow-lg border text-xs font-semibold animate-bounce transition-all ${
          toast.type === 'success' 
            ? 'bg-green-100 border-green-400 text-green-800' 
            : toast.type === 'error' 
            ? 'bg-red-100 border-red-400 text-red-800' 
            : 'bg-blue-100 border-blue-400 text-blue-800'
        }`}>
          <span>{toast.message}</span>
        </div>
      )}

      {/* Outer grid of panels */}
      <div className="flex flex-1 overflow-hidden w-full gap-1">
        
        {/* PANEL 3 & 4: CONTIGUOUS DESKTOP WORKSPACE */}
        <div className="flex-1 bg-[#9c9c9c] relative flex items-start gap-2 overflow-hidden p-0.5 w-full">
          
          {/* Top horizontal stripes spanning across behind the floating window */}
          <div className="absolute top-1.5 left-0 right-0 h-8 pointer-events-none z-0 flex flex-col justify-between">
            <div className="h-[4px] bg-[#225091] w-full" />
            <div className="h-[2px] bg-white w-full" />
            <div className="h-[4px] bg-[#cc2222] w-full" />
          </div>

          {/* FLOATING WINDOW: "إنشاء وإعتماد شهادات الصادر الجمركية" */}
          <div className="flex-1 h-full flex flex-col bg-[#dfdfdf] border-2 border-[#808080] border-l-white border-t-white p-0.5 overflow-hidden shadow-xl z-10" dir="rtl">
            
            {/* Classic Win9x title bar */}
            <div className="bg-gradient-to-r from-[#113a7a] to-[#2572b8] text-white px-2 py-0.5 flex items-center justify-between font-bold text-[11px] select-none">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 bg-teal-400 rounded-sm border border-white" />
                <span>إنشاء وإعتماد شهادات الصادر الجمركية</span>
              </div>
              <div className="flex items-center gap-0.5">
                <button className="w-4 h-3.5 bg-[#dfdfdf] text-black border border-white border-b-gray-600 border-r-gray-600 font-bold text-[9px] flex items-center justify-center">-</button>
                <button className="w-4 h-3.5 bg-[#dfdfdf] text-black border border-white border-b-gray-600 border-r-gray-600 font-bold text-[9px] flex items-center justify-center">□</button>
                <button className="w-4 h-3.5 bg-red-600 text-white border border-white border-b-gray-600 border-r-gray-600 font-bold text-[9px] flex items-center justify-center">X</button>
              </div>
            </div>

            {/* Split Main Body Layout inside window */}
            <div className="flex-1 flex flex-row-reverse overflow-hidden gap-1 p-1">

              {/* CONTAINER LIST SIDEBAR EMBEDDED DIRECTLY INSIDE WINDOW */}
              <div className="w-[200px] flex flex-col bg-[#eae9e1] border border-[#808080] p-1 flex-none" dir="rtl">
                <div className="flex items-center justify-between bg-[#dfdfdf] px-1 py-1 border border-[#808080] mb-1">
                  <span className="font-bold text-[10px] text-black flex items-center gap-1">
                    <input type="checkbox" className="w-3 h-3" defaultChecked />
                    <span>حاويات لها شهادة</span>
                  </span>
                  <button 
                    onClick={() => setLeftSearch('')}
                    className="p-0.5 bg-[#dfdfdf] border border-white border-b-[#808080] border-r-[#808080] active:border-[#808080] active:border-b-white active:border-r-white text-[9px] font-bold flex items-center justify-center cursor-pointer"
                    title="تحديث"
                  >
                    <RefreshCw className="w-2.5 h-2.5 text-gray-700" />
                  </button>
                </div>

                {/* Quick Filter Box */}
                <div className="mb-1 p-1 bg-white border border-[#808080]">
                  <input
                    type="text"
                    placeholder="بحث سريع..."
                    value={leftSearch}
                    onChange={(e) => setLeftSearch(e.target.value)}
                    className="w-full text-[10px] px-1 focus:outline-none text-right"
                    dir="rtl"
                  />
                </div>

                {/* Grid list */}
                <div className="flex-1 overflow-y-auto bg-[#808080] border border-[#808080]">
                  <table className="w-full text-[10px] border-collapse bg-white">
                    <thead>
                      <tr className="bg-[#dfdfdf] text-black font-bold border-b border-[#808080] text-center sticky top-0">
                        <th className="p-0.5 border-r border-[#808080] w-[15px]">&nbsp;</th>
                        <th className="p-0.5 border-r border-[#808080]">الخط</th>
                        <th className="p-0.5">الحاوية</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredLeftContainers.map((c) => (
                        <tr
                          key={c.id}
                          onClick={() => handleSelectLeftContainer(c.id)}
                          className={`cursor-pointer border-b border-gray-200 text-center text-[10px] hover:bg-blue-50 ${
                            selectedLeftId === c.id ? 'bg-[#000080] text-white' : 'text-black'
                          }`}
                        >
                          <td className="p-0.5 border-r border-gray-200">
                            <input 
                              type="checkbox" 
                              checked={selectedLeftId === c.id} 
                              onChange={() => handleSelectLeftContainer(c.id)}
                              className="w-2.5 h-2.5" 
                            />
                          </td>
                          <td className="p-0.5 border-r border-gray-200 font-bold">{c.line}</td>
                          <td className="p-0.5 font-mono font-bold text-[12px]">{c.id}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Refresh control bottom bar */}
                <div className="mt-1 flex justify-end">
                  <button
                    onClick={() => {
                      setLeftSearch('');
                      showToast('تم تحديث قائمة الحاويات المتاحة', 'info');
                    }}
                    className="bg-[#dfdfdf] border border-white border-b-[#808080] border-r-[#808080] active:border-[#808080] active:border-b-white active:border-r-white px-2 py-0.5 font-bold text-[9px] cursor-pointer hover:bg-gray-200 text-black"
                  >
                    Refresh
                  </button>
                </div>
              </div>

              {/* MAIN FORM AREA (scrollable) */}
              <div className="flex-1 flex flex-col overflow-y-auto gap-1">
                
                {/* FIRST ROW: Sub-Header "محضر إثبات حالة" and primary controls */}
                <div className="flex items-center justify-between bg-[#dfdfdf] border border-white border-b-gray-500 border-r-gray-500 p-1.5 flex-none">
                  
                  {/* Left action buttons */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => window.print()}
                      className="bg-[#5af15a] hover:bg-green-400 text-black font-bold text-[11px] px-3 py-1 border border-white border-b-gray-600 border-r-gray-600 active:border-gray-600 active:border-b-white active:border-r-white shadow-sm flex items-center gap-1 cursor-pointer"
                    >
                      <Printer className="w-3 h-3" />
                      <span>طباعة المحضر</span>
                    </button>
                    <button
                      onClick={handleNewFile}
                      className="bg-white text-black font-bold text-[11px] px-3 py-1 border border-white border-b-gray-600 border-r-gray-600 active:border-gray-600 active:border-b-white active:border-r-white shadow-sm flex items-center gap-1 cursor-pointer"
                    >
                      <File className="w-3 h-3 text-amber-500" />
                      <span>ملف جديد</span>
                    </button>
                  </div>

                  {/* Centered Case Proof Title */}
                  <div className="border border-gray-600 px-8 py-0.5 bg-white shadow-inner rounded-none">
                    <span className="font-bold text-[13px] text-black font-sans">
                      محضر إثبات حالة
                    </span>
                  </div>

                  {/* Right date picker */}
                  <div className="flex items-center gap-1 text-[11px]">
                    <span className="font-bold text-black">التاريخ:</span>
                    <div className="flex items-center bg-white border border-[#808080] pr-1 pl-1">
                      <input
                        type="text"
                        value={activeCert.date}
                        onChange={(e) => setActiveCert({ ...activeCert, date: e.target.value })}
                        className="w-20 text-[11px] outline-none text-center font-bold"
                      />
                      <button className="bg-gray-200 border-l border-gray-400 px-1 font-bold text-[10px]">▼</button>
                    </div>
                  </div>

                </div>

                {/* SECOND ROW: Simplified Container Display & Manual Inputs as requested */}
                <div className="bg-[#dfdfdf] border border-white border-b-[#808080] border-r-[#808080] p-4 flex flex-col gap-4 text-right flex-none">
                  
                  {/* 1. Large Light Green Container Display Box */}
                  <div className="w-full bg-[#b5eca8] border border-black py-2.5 px-4 shadow-sm flex items-center justify-center">
                    <span className="font-mono font-bold text-[18px] text-black tracking-wider uppercase">
                      {(selectedLeftId || activeCert.containers[0]?.containerId || "").toUpperCase()}
                    </span>
                  </div>

                  {/* 2. Side-by-side Inputs (التابعه لتوكيل & MAE swap) */}
                  <div className="flex gap-4">
                    {/* Right: التابعه لتوكيل manual text input */}
                    <div className="flex-1">
                      <input
                        type="text"
                        value={activeCert.agencyText || ''}
                        onChange={(e) => setActiveCert({ ...activeCert, agencyText: e.target.value })}
                        placeholder="التابعه لتوكيل"
                        className="w-full bg-white text-black border border-black py-1.5 px-3 text-center font-bold text-[13px] outline-none shadow-sm font-sans"
                      />
                    </div>

                    {/* Left: MAE manual text input */}
                    <div className="flex-1">
                      <input
                        type="text"
                        value={activeCert.maeCode || ''}
                        onChange={(e) => setActiveCert({ ...activeCert, maeCode: e.target.value })}
                        placeholder="MAE"
                        className="w-full bg-white text-black border border-black py-1.5 px-3 text-center font-bold text-[13px] outline-none shadow-sm font-sans"
                      />
                    </div>
                  </div>

                  {/* Sub-Footer control buttons of form */}
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-300">
                    
                    {/* Left last modified info */}
                    <div className="text-[10px] font-bold text-gray-600 font-mono">
                      آخر تعديل: {lastModified}
                    </div>

                    {/* Saving Actions */}
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => {
                          setActiveCert({ ...activeCert, maeCode: '', agencyText: '' });
                          showToast('تم مسح البيانات بنجاح', 'info');
                        }}
                        className="bg-[#f4be9b] hover:bg-[#ffb280] text-black font-extrabold text-[11px] px-5 py-1 border border-white border-b-[#808080] border-r-[#808080] active:border-[#808080] active:border-b-white active:border-r-white cursor-pointer"
                      >
                        مسح البيانات
                      </button>
                      <button
                        onClick={handleApproveCertificate}
                        className="bg-[#dfdfdf] text-black font-extrabold text-[11px] px-5 py-1 border border-white border-b-[#808080] border-r-[#808080] active:border-[#808080] active:border-b-white active:border-r-white cursor-pointer hover:bg-gray-200"
                      >
                        إعتماد
                      </button>
                      <button
                        onClick={handleSaveCertificate}
                        className="bg-[#dfdfdf] text-black font-extrabold text-[11px] px-5 py-1 border border-white border-b-[#808080] border-r-[#808080] active:border-[#808080] active:border-b-white active:border-r-white cursor-pointer hover:bg-gray-200"
                      >
                        حفظ
                      </button>
                    </div>

                  </div>

                </div>

                {/* THIRD PART: BOTTOM DATAGRID / TABLE */}
                <div className="bg-[#dfdfdf] border border-gray-400 p-0.5 flex flex-col gap-0.5 flex-none">
                  
                  <div className="flex items-center justify-between px-1.5 py-1 bg-[#d8d8d8] border border-[#808080]">
                    <span className="font-bold text-[11px] text-black">جدول الشهادات المعتمدة والمسجلة</span>
                    <button
                      onClick={handleAddNewRow}
                      className="bg-[#2da343] hover:bg-green-700 text-white font-bold text-[10px] px-2 py-0.5 border border-white border-b-gray-700 border-r-gray-700 active:border-gray-700 cursor-pointer flex items-center gap-1"
                    >
                      <span>إضافة سطر جديد ➕</span>
                    </button>
                  </div>

                  <div className="overflow-x-auto border border-[#808080] bg-[#808080] max-h-[300px] shadow-inner h-[260px]">
                    <table className="w-full text-[11px] text-center border-collapse bg-white table-fixed" style={{ minWidth: '950px' }}>
                      <thead>
                        <tr className="bg-[#dfdfdf] text-black font-bold border-b border-[#808080] text-center sticky top-0 z-10">
                          <th className="p-1 border-r border-[#808080] w-[100px]">رقم شهادة</th>
                          <th className="p-1 border-r border-[#808080] w-[60px]">سنه</th>
                          <th className="p-1 border-r border-[#808080] w-[110px]">نوعها</th>
                          <th className="p-1 border-r border-[#808080] w-[110px]">جمرك الارسال</th>
                          <th className="p-1 border-r border-[#808080] w-[110px]">الواجهه النهائيه</th>
                          <th className="p-1 border-r border-[#808080] w-[110px]">نوع المشمول</th>
                          <th className="p-1 border-r border-[#808080] w-[130px]">اسم العميل</th>
                          <th className="p-1 border-r border-[#808080] w-[60px]">الكميه</th>
                          <th className="p-1 border-r border-[#808080] w-[70px]">النوع</th>
                          <th className="p-1 border-r border-[#808080] w-[50px]">حفظ</th>
                          <th className="p-1 w-[50px]">حذف</th>
                        </tr>
                      </thead>
                      <tbody>
                        {certificatesList.map((cert) => {
                          const rowKey = cert.localId || cert.id;
                          const isActiveRow = (activeCert.localId && activeCert.localId === cert.localId) || (!activeCert.localId && activeCert.id === cert.id);
                          return (
                            <tr
                              key={rowKey}
                              onClick={() => setActiveCert(cert)}
                              className={`border-b border-gray-200 cursor-pointer text-center text-[10px] h-8 ${
                                isActiveRow ? 'bg-blue-100 font-semibold text-blue-900' : 'hover:bg-gray-50'
                              }`}
                            >
                              {/* رقم شهادة */}
                              <td className="p-0.5 border-r border-gray-200" onClick={(e) => e.stopPropagation()}>
                                <input
                                  type="text"
                                  value={cert.id}
                                  onChange={(e) => handleUpdateRowID(rowKey, e.target.value)}
                                  className="w-full text-center border border-gray-300 font-mono text-[10px] p-0.5 font-bold"
                                />
                              </td>

                              {/* سنه */}
                              <td className="p-0.5 border-r border-gray-200" onClick={(e) => e.stopPropagation()}>
                                <input
                                  type="text"
                                  value={cert.year}
                                  onChange={(e) => handleUpdateRowValue(rowKey, 'year', e.target.value)}
                                  className="w-full text-center border border-gray-300 font-mono text-[10px] p-0.5"
                                />
                              </td>

                              {/* نوعها */}
                              <td className="p-0.5 border-r border-gray-200" onClick={(e) => e.stopPropagation()}>
                                <select
                                  value={cert.type}
                                  onChange={(e) => handleUpdateRowValue(rowKey, 'type', e.target.value)}
                                  className="w-full text-center border border-gray-300 text-[10px] p-0.5 bg-white font-sans font-bold"
                                >
                                  <option value="صادر نهائي (Final Export)">صادر نهائي</option>
                                  <option value="إعادة تصدير (Re-export)">إعادة تصدير</option>
                                  <option value="ترانزيت (Transit)">ترانزيت</option>
                                </select>
                              </td>

                              {/* جمرك الارسال */}
                              <td className="p-0.5 border-r border-gray-200" onClick={(e) => e.stopPropagation()}>
                                <select
                                  value={cert.customsOffice}
                                  onChange={(e) => handleUpdateRowValue(rowKey, 'customsOffice', e.target.value)}
                                  className="w-full text-center border border-gray-300 text-[10px] p-0.5 bg-white"
                                >
                                  {CUSTOMS_OFFICES.map((office) => (
                                    <option key={office} value={office}>{office.split(' ')[0]}</option>
                                  ))}
                                </select>
                              </td>

                              {/* الواجهه النهائيه */}
                              <td className="p-0.5 border-r border-gray-200" onClick={(e) => e.stopPropagation()}>
                                <input
                                  type="text"
                                  value={cert.finalDestination || ''}
                                  onChange={(e) => handleUpdateRowValue(rowKey, 'finalDestination', e.target.value)}
                                  className="w-full text-center border border-gray-300 text-[10px] p-0.5 font-bold"
                                  placeholder="الوجهة"
                                />
                              </td>

                              {/* نوع المشمول */}
                              <td className="p-0.5 border-r border-gray-200" onClick={(e) => e.stopPropagation()}>
                                <select
                                  value={cert.cargoType}
                                  onChange={(e) => handleUpdateRowValue(rowKey, 'cargoType', e.target.value)}
                                  className="w-full text-center border border-gray-300 text-[10px] p-0.5 bg-white"
                                >
                                  {CARGO_TYPES.map((cargo) => (
                                    <option key={cargo} value={cargo}>{cargo.split(' ')[0]}</option>
                                  ))}
                                </select>
                              </td>

                              {/* اسم العميل */}
                              <td className="p-0.5 border-r border-gray-200" onClick={(e) => e.stopPropagation()}>
                                <input
                                  type="text"
                                  value={cert.clientName}
                                  onChange={(e) => handleUpdateRowValue(rowKey, 'clientName', e.target.value)}
                                  className="w-full text-right border border-gray-300 text-[10px] p-0.5 font-bold"
                                />
                              </td>

                              {/* الكميه */}
                              <td className="p-0.5 border-r border-gray-200" onClick={(e) => e.stopPropagation()}>
                                <input
                                  type="number"
                                  value={cert.totalQuantity}
                                  onChange={(e) => handleUpdateRowValue(rowKey, 'totalQuantity', parseInt(e.target.value) || 0)}
                                  className="w-full text-center border border-gray-300 text-[10px] p-0.5"
                                />
                              </td>

                              {/* النوع */}
                              <td className="p-0.5 border-r border-gray-200" onClick={(e) => e.stopPropagation()}>
                                <input
                                  type="text"
                                  value={cert.cargoSubtype || ''}
                                  onChange={(e) => handleUpdateRowValue(rowKey, 'cargoSubtype', e.target.value)}
                                  className="w-full text-center border border-gray-300 text-[10px] p-0.5"
                                  placeholder="النوع..."
                                />
                              </td>

                              {/* حفظ السطر */}
                              <td className="p-0.5 border-r border-gray-200" onClick={(e) => e.stopPropagation()}>
                                <button
                                  onClick={() => handleSaveRow(rowKey)}
                                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-[9px] px-1 py-0.5 rounded shadow-sm"
                                >
                                  حفظ
                                </button>
                              </td>

                              {/* حذف السطر */}
                              <td className="p-0.5" onClick={(e) => e.stopPropagation()}>
                                <button
                                  onClick={() => handleDeleteRow(rowKey)}
                                  className="bg-red-600 hover:bg-red-700 text-white font-bold text-[9px] px-1 py-0.5 rounded shadow-sm"
                                >
                                  حذف
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* Grid status footer buttons precisely matching the screenshot's color lights */}
                  <div className="flex items-center justify-between bg-[#dfdfdf] p-1 border border-white border-b-gray-600 border-r-gray-600">
                    
                    {/* Left Action: Approve Containers */}
                    <button
                      onClick={() => {
                        showToast('تم اعتماد جميع الشهادات المدخلة بنجاح', 'success');
                      }}
                      className="bg-[#dfdfdf] border border-white border-b-[#808080] border-r-[#808080] active:border-[#808080] active:border-b-white active:border-r-white px-4 py-1 font-bold text-[11px] cursor-pointer hover:bg-gray-200"
                    >
                      إعتماد جميع الشهادات
                    </button>

                    {/* Status Color buttons with light indicators */}
                    <div className="flex items-center gap-1">
                      {/* Ready for shipment (Green) */}
                      <button
                        onClick={() => {
                          if (!activeCert.id) {
                            showToast('يرجى تحديد شهادة أولاً', 'error');
                            return;
                          }
                          showToast(`الشهادة ${activeCert.id} جاهزة للشحن`, 'success');
                        }}
                        className="bg-green-700 hover:bg-green-800 text-white font-bold text-[11px] px-3 py-1 flex items-center gap-2 border border-white border-b-green-950 border-r-green-950 active:border-green-950 cursor-pointer"
                      >
                        <span className="w-2 h-2 rounded-full bg-green-300 border border-white shadow-sm animate-pulse" />
                        <span>جاهزة للشحن</span>
                      </button>

                      {/* Hold docs (Yellow) */}
                      <button
                        onClick={() => {
                          if (!activeCert.id) {
                            showToast('يرجى تحديد شهادة أولاً', 'error');
                            return;
                          }
                          showToast(`تم إيقاف الشهادة ${activeCert.id} لاستكمال المستندات`, 'info');
                        }}
                        className="bg-[#dca11c] hover:bg-yellow-600 text-white font-bold text-[11px] px-3 py-1 flex items-center gap-2 border border-white border-b-yellow-950 border-r-yellow-950 active:border-yellow-950 cursor-pointer"
                      >
                        <span className="w-2 h-2 rounded-full bg-yellow-300 border border-white shadow-sm" />
                        <span>وقف لإستكمال المستندات</span>
                      </button>

                      {/* Hold inspect (Red) */}
                      <button
                        onClick={() => {
                          if (!activeCert.id) {
                            showToast('يرجى تحديد شهادة أولاً', 'error');
                            return;
                          }
                          showToast(`تم إيقاف الشهادة ${activeCert.id} للكشف المعملي`, 'info');
                        }}
                        className="bg-[#dc1c1c] hover:bg-red-700 text-white font-bold text-[11px] px-3 py-1 flex items-center gap-2 border border-white border-b-red-950 border-r-red-950 active:border-red-950 cursor-pointer"
                      >
                        <span className="w-2 h-2 rounded-full bg-red-300 border border-white shadow-sm" />
                        <span>وقف للكشف</span>
                      </button>
                    </div>

                  </div>

                </div>

              </div>

            </div>

          </div>

          {/* DESKTOP BACKGROUND GRAPHICS: IT DEVELOPMENT TEAM & GATE SYSTEM BANNER */}
          <div className="w-[280px] h-full flex flex-col justify-between items-end select-none relative pr-1 pb-1 z-10 pt-8" dir="ltr">
            
            {/* IT Development Team Header with 3D shadow exactly matching the beveled style */}
            <div className="w-full text-right pr-2">
              <h1 className="text-[26px] font-black tracking-wide text-[#113a7a] font-sans drop-shadow-[2px_2px_0px_rgba(255,255,255,0.9)] uppercase leading-none filter saturate-150"
                  style={{ textShadow: '2px 2px 0px #ffffff, 4px 4px 0px rgba(0,0,0,0.2)' }}>
                IT Development Team
              </h1>
            </div>

            {/* Central Watermark compass */}
            <div className="w-full flex justify-center items-center py-6 opacity-30">
              <div className="w-24 h-24 border-2 border-dashed border-[#113a7a] rounded-full flex items-center justify-center">
                <span className="text-[9px] text-[#113a7a] font-mono font-bold tracking-widest">SCCT SYSTEM</span>
              </div>
            </div>

            {/* Red shape banner on the bottom right with GATE SYSTEM text & logo */}
            <div className="w-full flex justify-end">
              <div className="w-full bg-[#b31414] py-1 pl-4 pr-1 flex items-center justify-between border-t border-b border-red-800 shadow-md relative"
                   style={{ clipPath: 'polygon(15px 0, 100% 0, 100% 100%, 0 100%)' }}>
                
                {/* Spaced out classic GATE SYSTEM text */}
                <span className="font-extrabold text-[15px] text-[#113a7a] tracking-[0.25em] pl-4 uppercase font-sans drop-shadow-[1px_1px_0px_rgba(255,255,255,0.7)]">
                  GATE SYSTEM
                </span>

                {/* SCCT Small Oval Logo */}
                <div className="w-12 h-6 border border-[#113a7a] rounded-full flex items-center justify-center bg-white shadow-sm overflow-hidden relative">
                  <div className="absolute w-[120%] h-0.5 bg-red-600 rotate-[12deg]" />
                  <span className="text-[7px] font-extrabold text-[#113a7a] z-10">SCCT</span>
                </div>

              </div>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
};
